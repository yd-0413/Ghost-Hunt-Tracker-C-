#include "defs.h"

int main() {
    BuildingType *building = (BuildingType *)malloc(sizeof(BuildingType));
    if (building == NULL) {
        fprintf(stderr, "Error: Unable to allocate memory for building.\n");
        return 1; //This will return if memory allocation failed
    }

    initBuilding(building);
    loadBuildingData(building);

    int choice = 1;
    while (choice != 0) {
        printMenu(&choice);

        if (choice < 0 || choice > 4) {
            printf("This is an invalid selection\n");
            choice = -1; //This will rset choice to prevent infinite loop
            continue; //This will skip the rest of the loop and prompt again
        }

        switch (choice) {
            case 1:
                printRooms(&(building->rooms));
                break;
            case 2:
                printGhostList(&(building->ghosts));
                break;
            case 3:
                printByLikelihood(&(building->ghosts), 0);
                break;
            case 4:
                printByLikelihood(&(building->ghosts), 1);
                break;
            default:
                printf("This is an invalid selection\n");
                break;
        }
    }

    cleanupBuilding(building);
    free(building); //This will free the building memory after cleanup

    return 0;
}

void printMenu(int *choice) {
    printf("\nMAIN MENU\n");
    printf("  (1) Print rooms\n");
    printf("  (2) Print ghosts\n");
    printf("  (3) Print ghosts by likelihood\n");
    printf("  (4) Print most/least likely ghosts\n");
    printf("  (0) Exit\n\n");

    printf("Please enter your selection: ");
    scanf("%2d", choice);
    while (getchar() != '\n'); //This will clear the input buffer
}
