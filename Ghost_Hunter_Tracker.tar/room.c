#include "defs.h"

char elements [ 5 ];
//This code will initialize an array of RoomType elements
void initRoomArray(RoomArrayType *arr) {
    arr->size = 0;
    for (int i = 0; i < MAX_ARR; i++) {
        arr->elements[i] = NULL;
    }
}

//This code will initialize a room with the ID, name, and then it will return the pointer through the parameter list
void initRoom(int id, char *name, RoomType **room) {
    *room = (RoomType *)malloc(sizeof(RoomType));
    if (*room != NULL) {
        (*room)->id = id;
        strncpy((*room)->name, name, MAX_STR);
        (*room)->name[MAX_STR - 1] = '\0'; //This will terminate the null
        initGhostList(&(*room)->ghosts); //This will initialize the ghost list for the room and set it to the null value (indicating its empty)
        fprintf(stderr, "The init room has been allocated to a arraytype and intialized as empty");
    } else {
        fprintf(stderr, "Error: Unable to allocate memory for room.\n");//This will print out an error message that the program can't allocate the memory for the room
    }
}

//This will add a new room to the array of rooms in the building
void addRoom(RoomArrayType *arr, RoomType *room) {
    if (arr->size >= MAX_ARR) {
        fprintf(stderr, "Error: Room array is full. Cannot add more rooms.\n");
        free(room);
    }
    else
    {
    arr->elements[arr->size++] = room; //This will add room to array and increment size
    arr->size++;
    }
}


//This will give the user all of the required details for all the rooms
void printRooms(const RoomArrayType *arr) {
    printf("Current Rooms:\n");
    for (int i = 0; i < arr->size; i++) 
    {
        RoomType *room = arr->elements[i];
        printf("Room ID: %d, Name: %s\n", room->id, room->name);
        // Assuming printGhostList is defined to print ghosts in a room
        printGhostList(&(room->ghosts));
    }
}

//This will clean the array of rooms
void cleanupRoomArray(RoomArrayType *arr) {
    for (int i = 0; i < arr->size; i++) {
        // Assuming cleanupGhostList is defined to deallocate ghost list memory
        cleanupGhostList(&(arr->elements[i]->ghosts));
        free(arr->elements[i]);
        arr->elements[i] = NULL;
    }
    arr->size = 0; //This will reset the the size of the array
}