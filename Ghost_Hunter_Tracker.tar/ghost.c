#include "defs.h"

//This code will initialize the ghost list
void initGhostList(GhostListType *list) {
    list->head = NULL;
    list->tail = NULL;
}

void initGhost(int id, GhostEnumType gt, RoomType *r, float like, GhostType **ghost) {
    *ghost = (GhostType *)malloc(sizeof(GhostType));
    if (*ghost != NULL) {
        (*ghost)->id = id;
        (*ghost)->ghostType = gt;
        (*ghost)->room = r;
        (*ghost)->likelihood = like;
        //(*ghost)->ghostType = *gst;
    } else {
        fprintf(stderr, "Error: Unable to allocate me");
    }
}
        

//This will add the ghost to the list
void addGhost(GhostListType *list, GhostType *ghost) {
    NodeType *newNode = (NodeType *)malloc(sizeof(NodeType));
    if (newNode == NULL) {
        fprintf(stderr, "Error: Unable to allocate memory for node.\n");
        return;
    }

    newNode->ghost = ghost;
    newNode->next = NULL;

    if (list->head == NULL) {
        list->head = newNode;
        list->tail = newNode;
    } else {
        list->tail->next = newNode;
        list->tail = newNode;
    }
}

//This will add the ghost to the list by its likelihood
void addGhostByLikelihood(GhostListType *list, GhostType *ghost) {
    NodeType *newNode = (NodeType *)malloc(sizeof(NodeType));
    NodeType *current, *prev = NULL;
    newNode->ghost = ghost;
    newNode->next = NULL;

    if (list->head == NULL || list->head->ghost->likelihood <= ghost->likelihood) {
        newNode->next = list->head;
        list->head = newNode;
    } else {
        current = list->head;
        while (current != NULL && current->ghost->likelihood > ghost->likelihood) {
            prev = current;
            current = current->next;
        }
        newNode->next = current;
        if (prev) {
            prev->next = newNode;
        }
    }
    if (newNode->next == NULL) { //So if the new node is at the end, the code will then update the tail
        list->tail = newNode;
    }
}

//This will print all of the ghosts that are in the list
void printGhostList(const GhostListType *list) {
    NodeType *current = list->head;
    while (current != NULL) {
        printGhost(current->ghost);
        current = current->next;
    }
}

//This will print a ghost by its likelihood
void printByLikelihood(const GhostListType *origList, int endsOnly) {
    GhostListType sortedList = {NULL};
    NodeType *current;

    initGhostList(&sortedList); //This code will nitialize temporary sorted list

    //This will create the sorted list without changing the original data
    current = origList->head;
    while (current != NULL) {
        addGhostByLikelihood(&sortedList, current->ghost);
        current = current->next;
    }

    //This code will print the sorted list
    if (endsOnly == 1) { //let 1 = true and 0 = false 
        if (sortedList.head) { //This code will rint the most likely ghost
            printf("Most likely ghost:\n");
            printGhost(sortedList.head->ghost);
        }
        if (sortedList.tail && sortedList.tail != sortedList.head) { //This code will print the least likely ghost
            printf("Least likely ghost:\n");
            printGhost(sortedList.tail->ghost);
        }
    } else { //this will let 0 equal to false
        printGhostList(&sortedList);
    }

    cleanupGhostList(&sortedList); //This will cleanup the temporary list nodes
}

//This will print all of the details for a single ghost
void printGhost(const GhostType *ghost) 
{
    GhostEnumType ghostType = ghost->ghostType;
    char* name = (char *)malloc(20 * sizeof(char));


    if (ghostType == POLTERGEIST) 
    {
        strcpy(name, "Poltergeist");
    } 
    else if (ghostType == WRAITH) 
    {
        strcpy(name, "Wraith");
    } 
    else if (ghostType == PHANTOM) 
    {
        strcpy(name, "Phantom");
    } 
    else if (ghostType == BULLIES) 
    {
        strcpy(name, "Bullies");
    } 
    else if (ghostType == OTHER) 
    {
        strcpy(name, "Other");
    } 
    else 
    {
        return "Unknown";
    }
    if (ghost->room != NULL)
    {
    printf("id %d , type: %s , room: %s, likelihood: %.2f\n", ghost->id, name, ghost->room->name, ghost->likelihood);
    }
    else
    {
    printf("id %d , type: %s , room: %s, likelihood: %.2f\n", ghost->id, name, "Unknown room", ghost->likelihood); 
    }
    free(name);
}
       
// Clean up the ghost data only
void cleanupGhostData(GhostListType *list) {

    NodeType *current = list->head;
    NodeType *next;

    while (current != NULL) {
        next = current->next;
        free(current->ghost); //This code will free the ghost data
        current->ghost = NULL; //This will set the ghost pointer to a value of NULL
        current = next;
    }
}

//This will clean up the nodes only for the ghost list 
void cleanupGhostList(GhostListType *list) {
    NodeType *current = list->head;
    NodeType *next;
    while (current != NULL) {
        next = current->next;
        //this will assume that the cleanupGhostData is responsible for freeing  the ghost data
        free(current); //This will free the node itself
        current = next;
    }
    list->head = NULL; // Reset the head and tail to NULL after cleanup
    list->tail = NULL; // Reset the head and tail to NULL after cleanup
}
